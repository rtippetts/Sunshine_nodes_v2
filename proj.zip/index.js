let express = require("express");

let app = express();

let path = require("path");

const port = 5000;

app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));
app.use(express.urlencoded({extended: true}));

const knex = require("knex") ({
    client : "pg",
    connection : {
        host : 'database-1.cicrssmeudka.us-east-1.rds.amazonaws.com',
        user : "postgres",
        password : "th3b3stb3ars!",
        database : "postgres",
        port : 5432,
        ssl: {
            rejectUnauthorized: false,
        }
    }
})

app.get("/", (req, res) =>
    {
        knex.select().from('Users').then( users => {
            console.log('Query Returned');
            res.render("account", { myusers: users });
        }).catch(err => {
            console.log(err);
            res.status(500).json({err});
        });
    });

app.listen(port, () => console.log('Listening...'))